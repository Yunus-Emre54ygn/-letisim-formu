document.getElementById("iletisimForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const isim = document.getElementById("isim").value.trim();
    const email = document.getElementById("email").value.trim();
    const konu = document.getElementById("konu").value;
    const mesaj = document.getElementById("mesaj").value.trim();
    const bildirim = document.getElementById("bildirim");
  
    if (!isim || !email || !konu || !mesaj) {
      alert("Tüm alanları doldurmanız gerekmektedir.");
      return;
    }
  
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      alert("Geçerli bir e-posta adresi girin.");
      return;
    }
  
    bildirim.style.display = "block";
    setTimeout(() => {
      bildirim.style.display = "none";
    }, 3000);
  
    this.reset();
  });
  